export class ItemBucket extends Entity {
    constructor(
        transform: Transform
    ) {
        super()
        this.addComponent(new GLTFShape('models/bucket.gltf'))
        this.addComponent(transform)
        engine.addEntity(this);
    }
}