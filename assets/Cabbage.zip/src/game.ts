import * as utils from '@dcl/ecs-scene-utils'
import { ItemBucket } from './items/bucket'
import { PlantCabbage } from './items/plantCabbage'


const bucket1 = new ItemBucket(new Transform({
  position: new Vector3(8,0,8)
}))

const plantCabbage = new PlantCabbage(new Transform({
  position: new Vector3(7,0,7)
}))